﻿namespace EMS
{
    partial class frmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tlmBuy = new System.Windows.Forms.ToolStripMenuItem();
            this.fileBuyStock = new System.Windows.Forms.ToolStripMenuItem();
            this.fileRebuyStock = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.fileBuyStockSum = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tlmSale = new System.Windows.Forms.ToolStripMenuItem();
            this.fileSellStock = new System.Windows.Forms.ToolStripMenuItem();
            this.fileResellStock = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.fileSellStockSum = new System.Windows.Forms.ToolStripMenuItem();
            this.fileSellStockStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.fileSellStockOrderBy = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.fileSellStockCost = new System.Windows.Forms.ToolStripMenuItem();
            this.tlmStock = new System.Windows.Forms.ToolStripMenuItem();
            this.fileStockStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.fileUpperLimit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.fileCheckStock = new System.Windows.Forms.ToolStripMenuItem();
            this.tlmBase = new System.Windows.Forms.ToolStripMenuItem();
            this.fileStore = new System.Windows.Forms.ToolStripMenuItem();
            this.fileUnits = new System.Windows.Forms.ToolStripMenuItem();
            this.fileEmployee = new System.Windows.Forms.ToolStripMenuItem();
            this.tlmSystem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileUnit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.frmSysPopedom = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileEnd = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tlmBuy,
            this.tlmSale,
            this.tlmStock,
            this.tlmBase,
            this.tlmSystem,
            this.退出ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(894, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tlmBuy
            // 
            this.tlmBuy.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileBuyStock,
            this.fileRebuyStock,
            this.toolStripSeparator1,
            this.fileBuyStockSum,
            this.toolStripSeparator2});
            this.tlmBuy.Enabled = false;
            this.tlmBuy.Name = "tlmBuy";
            this.tlmBuy.Size = new System.Drawing.Size(84, 21);
            this.tlmBuy.Text = "进货管理(&B)";
            this.tlmBuy.Click += new System.EventHandler(this.tlmBuy_Click);
            // 
            // fileBuyStock
            // 
            this.fileBuyStock.Image = global::EMS.Properties.Resources._45;
            this.fileBuyStock.Name = "fileBuyStock";
            this.fileBuyStock.Size = new System.Drawing.Size(196, 22);
            this.fileBuyStock.Text = "进货单";
            this.fileBuyStock.Click += new System.EventHandler(this.fileBuyStock_Click);
            // 
            // fileRebuyStock
            // 
            this.fileRebuyStock.Image = global::EMS.Properties.Resources._44;
            this.fileRebuyStock.Name = "fileRebuyStock";
            this.fileRebuyStock.Size = new System.Drawing.Size(196, 22);
            this.fileRebuyStock.Text = "进货退货单";
            this.fileRebuyStock.Click += new System.EventHandler(this.fileRebuyStock_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(193, 6);
            // 
            // fileBuyStockSum
            // 
            this.fileBuyStockSum.Name = "fileBuyStockSum";
            this.fileBuyStockSum.Size = new System.Drawing.Size(196, 22);
            this.fileBuyStockSum.Text = "进货统计（不含退货）";
            this.fileBuyStockSum.Click += new System.EventHandler(this.fileBuyStockSum_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(193, 6);
            // 
            // tlmSale
            // 
            this.tlmSale.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileSellStock,
            this.fileResellStock,
            this.toolStripSeparator3,
            this.fileSellStockSum,
            this.fileSellStockStatus,
            this.fileSellStockOrderBy,
            this.toolStripSeparator4,
            this.fileSellStockCost});
            this.tlmSale.Enabled = false;
            this.tlmSale.Name = "tlmSale";
            this.tlmSale.Size = new System.Drawing.Size(83, 21);
            this.tlmSale.Text = "销售管理(&S)";
            // 
            // fileSellStock
            // 
            this.fileSellStock.Image = global::EMS.Properties.Resources._44;
            this.fileSellStock.Name = "fileSellStock";
            this.fileSellStock.Size = new System.Drawing.Size(196, 22);
            this.fileSellStock.Text = "销售单";
            this.fileSellStock.Click += new System.EventHandler(this.fileSellStock_Click);
            // 
            // fileResellStock
            // 
            this.fileResellStock.Image = global::EMS.Properties.Resources._44;
            this.fileResellStock.Name = "fileResellStock";
            this.fileResellStock.Size = new System.Drawing.Size(196, 22);
            this.fileResellStock.Text = "销售退货单";
            this.fileResellStock.Click += new System.EventHandler(this.fileResellStock_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(193, 6);
            // 
            // fileSellStockSum
            // 
            this.fileSellStockSum.Name = "fileSellStockSum";
            this.fileSellStockSum.Size = new System.Drawing.Size(196, 22);
            this.fileSellStockSum.Text = "销售统计（不含退货）";
            this.fileSellStockSum.Click += new System.EventHandler(this.fileSellStockSum_Click);
            // 
            // fileSellStockStatus
            // 
            this.fileSellStockStatus.Name = "fileSellStockStatus";
            this.fileSellStockStatus.Size = new System.Drawing.Size(196, 22);
            this.fileSellStockStatus.Text = "月销售状况";
            this.fileSellStockStatus.Click += new System.EventHandler(this.fileSellStockStatus_Click);
            // 
            // fileSellStockOrderBy
            // 
            this.fileSellStockOrderBy.Image = global::EMS.Properties.Resources._07;
            this.fileSellStockOrderBy.Name = "fileSellStockOrderBy";
            this.fileSellStockOrderBy.Size = new System.Drawing.Size(196, 22);
            this.fileSellStockOrderBy.Text = "商品销售排行";
            this.fileSellStockOrderBy.Click += new System.EventHandler(this.fileSellStockOrderBy_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(193, 6);
            // 
            // fileSellStockCost
            // 
            this.fileSellStockCost.Name = "fileSellStockCost";
            this.fileSellStockCost.Size = new System.Drawing.Size(196, 22);
            this.fileSellStockCost.Text = "商品销售成本表";
            this.fileSellStockCost.Click += new System.EventHandler(this.fileSellStockCost_Click);
            // 
            // tlmStock
            // 
            this.tlmStock.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileStockStatus,
            this.toolStripSeparator5,
            this.fileUpperLimit,
            this.toolStripSeparator6,
            this.fileCheckStock});
            this.tlmStock.Enabled = false;
            this.tlmStock.Name = "tlmStock";
            this.tlmStock.Size = new System.Drawing.Size(88, 21);
            this.tlmStock.Text = "库存管理(&W)";
            // 
            // fileStockStatus
            // 
            this.fileStockStatus.Image = global::EMS.Properties.Resources._171;
            this.fileStockStatus.Name = "fileStockStatus";
            this.fileStockStatus.Size = new System.Drawing.Size(184, 22);
            this.fileStockStatus.Text = "库存状况";
            this.fileStockStatus.Click += new System.EventHandler(this.fileStockStatus_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(181, 6);
            // 
            // fileUpperLimit
            // 
            this.fileUpperLimit.Name = "fileUpperLimit";
            this.fileUpperLimit.Size = new System.Drawing.Size(184, 22);
            this.fileUpperLimit.Text = "库存商品上下限报警";
            this.fileUpperLimit.Click += new System.EventHandler(this.fileUpperLimit_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(181, 6);
            // 
            // fileCheckStock
            // 
            this.fileCheckStock.Image = global::EMS.Properties.Resources.check;
            this.fileCheckStock.Name = "fileCheckStock";
            this.fileCheckStock.Size = new System.Drawing.Size(184, 22);
            this.fileCheckStock.Text = "库存盘点";
            this.fileCheckStock.Click += new System.EventHandler(this.fileCheckStock_Click);
            // 
            // tlmBase
            // 
            this.tlmBase.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileStore,
            this.fileUnits,
            this.fileEmployee});
            this.tlmBase.Enabled = false;
            this.tlmBase.Name = "tlmBase";
            this.tlmBase.Size = new System.Drawing.Size(85, 21);
            this.tlmBase.Text = "基础数据(&G)";
            // 
            // fileStore
            // 
            this.fileStore.Image = global::EMS.Properties.Resources._171;
            this.fileStore.Name = "fileStore";
            this.fileStore.Size = new System.Drawing.Size(124, 22);
            this.fileStore.Text = "库存商品";
            this.fileStore.Click += new System.EventHandler(this.fileStore_Click);
            // 
            // fileUnits
            // 
            this.fileUnits.Name = "fileUnits";
            this.fileUnits.Size = new System.Drawing.Size(124, 22);
            this.fileUnits.Text = "往来单位";
            this.fileUnits.Click += new System.EventHandler(this.fileUnits_Click);
            // 
            // fileEmployee
            // 
            this.fileEmployee.Image = global::EMS.Properties.Resources._42;
            this.fileEmployee.Name = "fileEmployee";
            this.fileEmployee.Size = new System.Drawing.Size(124, 22);
            this.fileEmployee.Text = "公司职员";
            this.fileEmployee.Click += new System.EventHandler(this.fileEmployee_Click);
            // 
            // tlmSystem
            // 
            this.tlmSystem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileUnit,
            this.toolStripSeparator10,
            this.frmSysPopedom,
            this.toolStripSeparator11});
            this.tlmSystem.Enabled = false;
            this.tlmSystem.Name = "tlmSystem";
            this.tlmSystem.Size = new System.Drawing.Size(88, 21);
            this.tlmSystem.Text = "系统维护(&M)";
            // 
            // fileUnit
            // 
            this.fileUnit.Name = "fileUnit";
            this.fileUnit.Size = new System.Drawing.Size(148, 22);
            this.fileUnit.Text = "本单位信息";
            this.fileUnit.Click += new System.EventHandler(this.本单位ToolStripMenuItem_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(145, 6);
            // 
            // frmSysPopedom
            // 
            this.frmSysPopedom.Name = "frmSysPopedom";
            this.frmSysPopedom.Size = new System.Drawing.Size(148, 22);
            this.frmSysPopedom.Text = "系统管理设置";
            this.frmSysPopedom.Click += new System.EventHandler(this.frmSysPopedom_Click);
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(145, 6);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileEnd});
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(59, 21);
            this.退出ToolStripMenuItem.Text = "退出(&E)";
            // 
            // fileEnd
            // 
            this.fileEnd.Image = global::EMS.Properties.Resources.Close;
            this.fileEnd.Name = "fileEnd";
            this.fileEnd.Size = new System.Drawing.Size(148, 22);
            this.fileEnd.Text = "直接退出系统";
            this.fileEnd.Click += new System.EventHandler(this.fileEnd_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(894, 423);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "图书进销存管理系统";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmMain_FormClosed);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileBuyStock;
        private System.Windows.Forms.ToolStripMenuItem fileRebuyStock;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem fileBuyStockSum;
        private System.Windows.Forms.ToolStripMenuItem fileSellStock;
        private System.Windows.Forms.ToolStripMenuItem fileResellStock;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem fileSellStockSum;
        private System.Windows.Forms.ToolStripMenuItem fileSellStockStatus;
        private System.Windows.Forms.ToolStripMenuItem fileSellStockOrderBy;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem fileSellStockCost;
        private System.Windows.Forms.ToolStripMenuItem fileStockStatus;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem fileUpperLimit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem fileCheckStock;
        private System.Windows.Forms.ToolStripMenuItem fileStore;
        private System.Windows.Forms.ToolStripMenuItem fileUnits;
        private System.Windows.Forms.ToolStripMenuItem fileEmployee;
        private System.Windows.Forms.ToolStripMenuItem fileUnit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem frmSysPopedom;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripMenuItem fileEnd;
        public System.Windows.Forms.ToolStripMenuItem tlmBuy;
        public System.Windows.Forms.ToolStripMenuItem tlmSale;
        public System.Windows.Forms.ToolStripMenuItem tlmStock;
        public System.Windows.Forms.ToolStripMenuItem tlmBase;
        public System.Windows.Forms.ToolStripMenuItem tlmSystem;
    }
}

