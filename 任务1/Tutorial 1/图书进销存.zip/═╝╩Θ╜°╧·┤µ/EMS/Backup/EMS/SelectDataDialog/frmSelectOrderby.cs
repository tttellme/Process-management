using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EMS.SelectDataDialog
{
    public partial class frmSelectOrderby : Form
    {
        BaseClass.BaseInfo baseinfo = new EMS.BaseClass.BaseInfo();
        public frmSelectOrderby()
        {
            InitializeComponent();
        }

        private void frmSelectOrderby_Load(object sender, EventArgs e)
        {
            DataSet ds = null;
            //����������λ�б�
            ds = baseinfo.SetUnitsList("tb_units");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                cmbUnits.Items.Add(ds.Tables[0].Rows[i]["fullname"].ToString());
            }
            //���þ������б�
            ds = baseinfo.SetHandleList("tb_employee");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {

                cmbHandle.Items.Add(ds.Tables[0].Rows[i]["fullname"].ToString());
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            SaleStock.frmSellStockDesc sellStockDesc = new EMS.SaleStock.frmSellStockDesc();
            DataSet ds = null;
            if (rdbSaleSum.Checked)
            {
                ds = baseinfo.GetTSumDesc(cmbHandle.Text, cmbUnits.Text, dtpStar.Value, dtpEnd.Value, "tb_desc");
                sellStockDesc.dgvStockList.DataSource = ds.Tables[0].DefaultView;
            }
            else
            {
                ds = baseinfo.GetQtyDesc(cmbHandle.Text, cmbUnits.Text, dtpStar.Value, dtpEnd.Value, "tb_desc");
                sellStockDesc.dgvStockList.DataSource = ds.Tables[0].DefaultView;
            }
            sellStockDesc.Show();
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}